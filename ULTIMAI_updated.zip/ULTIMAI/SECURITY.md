# Security Policy

This project uses only local resources and does not connect to external services.  There are no known vulnerabilities.  If you discover a security issue, please open an issue or submit a pull request.