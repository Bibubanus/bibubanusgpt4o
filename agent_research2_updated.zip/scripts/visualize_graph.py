#!/usr/bin/env python3
"""Render a reasoning graph to an image.

This script loads a graph saved by the reasoning infrastructure and
produces a PNG (or other supported format) showing the nodes and edges.
It falls back to NetworkX drawing if PyGraphviz is unavailable.

Usage:
  python visualize_graph.py --graph path/to/graph.json --output graph.png
"""

import argparse
from pathlib import Path
import json

# Try to import networkx; fall back to the local stub if unavailable.
try:
    import networkx as nx  # type: ignore
except ImportError:
    from ultimai import networkx_stub as nx  # type: ignore

from ultimai.graph_manager import ReasoningGraph


def draw_with_matplotlib(g: nx.DiGraph, output: str) -> bool:
    """Attempt to draw the graph with matplotlib.

    Returns True if successful, False otherwise.  When running in a restricted
    environment without matplotlib, the function returns False and the caller
    should fall back to another method.
    """
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except ImportError:
        return False
    # Some stub graphs may not implement spring_layout; guard accordingly
    if not hasattr(nx, 'spring_layout') or not hasattr(nx, 'draw'):
        return False
    plt.figure(figsize=(10, 8))
    pos = nx.spring_layout(g, seed=42)
    labels = {n: data.get('label', n) for n, data in g.nodes(data=True)}
    nx.draw(g, pos, labels=labels, with_labels=True, node_size=500, font_size=8)
    plt.tight_layout()
    plt.savefig(output)
    plt.close()
    return True


def draw_with_graphviz(g: nx.DiGraph, output: str) -> bool:
    """Attempt to draw the graph with pygraphviz.

    Returns True if successful, False otherwise.
    """
    try:
        import pygraphviz as pgv  # type: ignore
    except ImportError:
        return False
    # Ensure that the adapter exists on the networkx module
    if not hasattr(nx, 'nx_agraph'):
        return False
    A = nx.nx_agraph.to_agraph(g)
    A.layout('dot')
    A.draw(output)
    return True


def main() -> None:
    parser = argparse.ArgumentParser(description="Visualise a reasoning graph")
    parser.add_argument('--graph', required=True, help='Path to the graph JSON file')
    parser.add_argument('--output', required=True, help='Output image file (e.g., graph.png)')
    args = parser.parse_args()

    rg = ReasoningGraph()
    rg.load(args.graph)
    g = rg.graph
    out_path = args.output
    if draw_with_graphviz(g, out_path):
        print(f"Graph image saved to {out_path} using Graphviz")
        return
    if draw_with_matplotlib(g, out_path):
        print(f"Graph image saved to {out_path} using matplotlib")
        return
    # Fallback when neither visualisation library is available
    print("No visualisation backend available (pygraphviz or matplotlib missing).\n"
          f"Could not render graph; falling back to textual export in {out_path}.txt")
    # Write a simple textual representation as a fallback
    text_output = out_path + ".txt"
    with open(text_output, 'w', encoding='utf-8') as f:
        f.write("Nodes:\n")
        for n, attrs in g.nodes(data=True):  # type: ignore
            f.write(f"  {n}: {attrs}\n")
        f.write("Edges:\n")
        for u, v, attrs in g.edges(data=True):  # type: ignore
            f.write(f"  {u} -> {v}: {attrs}\n")
    print(f"Graph text saved to {text_output}")


if __name__ == '__main__':
    main()