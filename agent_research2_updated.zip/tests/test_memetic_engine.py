"""Tests for the MemeticEngine in ultimai.memetic_algorithm.

These tests ensure that running the memetic algorithm does not corrupt
the underlying reasoning graph and that node scores remain within the
expected range of [0, 1].
"""

import random


from ultimai.graph_manager import ReasoningGraph, NodeData
from ultimai.memetic_algorithm import MemeticEngine


def build_simple_graph() -> ReasoningGraph:
    rg = ReasoningGraph()
    # Three nodes with initial scores
    rg.add_node("A", NodeData(label="A", score=0.5))
    rg.add_node("B", NodeData(label="B", score=0.5))
    rg.add_node("C", NodeData(label="C", score=0.5))
    # connect them
    rg.add_edge("A", "B", relation="supports", weight=1.0)
    rg.add_edge("B", "C", relation="contradicts", weight=0.5)
    rg.add_edge("A", "C", relation="resolves", weight=0.8)
    return rg


def test_memetic_run_does_not_change_node_count() -> None:
    random.seed(42)
    rg = build_simple_graph()
    engine = MemeticEngine(rg)
    initial_nodes = set(rg.graph.nodes())
    engine.run(iterations=5)
    # Graph should have same nodes
    assert set(rg.graph.nodes()) == initial_nodes


def test_memetic_scores_within_bounds() -> None:
    random.seed(123)
    rg = build_simple_graph()
    engine = MemeticEngine(rg)
    engine.run(iterations=5)
    # All scores should be between 0 and 1 after evolution
    for _, attrs in rg.graph.nodes(data=True):
        score = attrs.get('score')
        assert 0.0 <= score <= 1.0