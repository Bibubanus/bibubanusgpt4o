"""Simple test runner for the ULTIMAI reasoning infrastructure.

This script discovers and executes test functions defined in modules whose
names start with ``test_`` under the current directory.  It is a lightweight
alternative to ``pytest`` that avoids external dependencies and can run in
restricted environments.  The runner supports a rudimentary fixture for
``tmp_path`` parameters by creating a temporary directory and passing a
``pathlib.Path`` instance to the test function.

Each test function should either accept no arguments or a single argument
named ``tmp_path``, which will be supplied automatically.  Functions
raising an exception are considered failures.  At the end of the run the
script reports the number of tests executed and failures.  It exits with
status 1 if any test fails.
"""

from __future__ import annotations

import importlib
import inspect
import os
from pathlib import Path
import pkgutil
import traceback
from tempfile import TemporaryDirectory

# Ensure the parent directory (agent_code) is in sys.path so that modules
# under ``ultimai`` can be imported when running tests directly.
import sys
parent_dir = Path(__file__).resolve().parent.parent
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))


def run() -> None:
    """Discover and execute test functions in test modules."""
    # Determine the package name for this directory
    package_name = __package__
    # Fallback to empty package when executed as a script
    if not package_name:
        package_name = 'tests'
    tests_dir = Path(__file__).parent
    failed = 0
    total = 0
    for module_info in pkgutil.iter_modules([str(tests_dir)]):
        if not module_info.name.startswith('test_'):
            continue
        # import the module by name relative to the current working directory
        module_name = module_info.name
        try:
            module = importlib.import_module(module_name)
        except Exception:
            print(f"Failed to import {module_name}\n{traceback.format_exc()}")
            failed += 1
            continue
        # iterate over functions
        for name, func in inspect.getmembers(module, inspect.isfunction):
            if not name.startswith('test_'):
                continue
            total += 1
            try:
                if func.__code__.co_argcount == 0:
                    func()
                elif func.__code__.co_argcount == 1:
                    # Provide a temporary directory as a Path for tmp_path
                    with TemporaryDirectory() as tmpdir:
                        tmp_path = Path(tmpdir)
                        func(tmp_path)
                else:
                    raise ValueError(f"Test function {name} in {module_name} has unsupported signature")
                print(f"PASS {module_info.name}:{name}")
            except Exception:
                failed += 1
                print(f"FAIL {module_info.name}:{name}\n{traceback.format_exc()}")
    print(f"Executed {total} tests, {failed} failures")
    if failed:
        raise SystemExit(1)


if __name__ == '__main__':
    run()