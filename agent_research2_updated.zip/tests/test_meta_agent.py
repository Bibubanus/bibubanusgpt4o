"""Tests for the MetaAgent orchestrator.

These tests ensure that the meta‑agent can load data, build a graph, run
memetic evolution, quarantine, audit and save the graph without
errors.  It uses a temporary CSV file for input and a temporary JSON
file for output.
"""

from pathlib import Path
import json
from tempfile import TemporaryDirectory

from ultimai.meta_agent import MetaAgent, MetaConfig


def test_full_cycle() -> None:
    """Test that the meta‑agent completes a full reasoning cycle."""
    # create a temporary working directory
    with TemporaryDirectory() as tmpdir:
        csv_path = Path(tmpdir) / 'input.csv'
        csv_path.write_text(
            "source_id,source_label,target_id,target_label,relation,source_score,target_score\n"
            "A,God,B,Logic,influences,0.6,0.7\n"
            "B,Logic,C,Absurdity,contradicts,0.7,0.5\n"
            "A,God,C,Absurdity,resolves,0.6,0.5\n"
        )
        json_path = Path(tmpdir) / 'output.json'
        agent = MetaAgent(config=MetaConfig(memetic_iterations=2, quarantine_threshold=0.3, reintegrate_threshold=0.4))
        # run full cycle
        agent.full_cycle(csv_path=str(csv_path), save_path=str(json_path))
        # read saved graph
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        assert data  # file should contain some serialised graph structure