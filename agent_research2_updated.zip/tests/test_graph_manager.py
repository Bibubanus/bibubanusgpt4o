"""Tests for the ReasoningGraph class in ultimai.graph_manager.

These tests verify that nodes and edges can be added correctly, that graphs
can be constructed from CSV files, and that basic metrics operate as
expected.  They are intentionally lightweight so that they can run quickly
in a CI environment without external dependencies beyond those listed in
``requirements.txt``.
"""

from pathlib import Path
import tempfile

import pandas as pd
import math

from ultimai.graph_manager import ReasoningGraph, NodeData


def test_add_nodes_and_edges() -> None:
    rg = ReasoningGraph()
    # add two nodes
    rg.add_node("X", NodeData(label="X concept", score=0.8))
    rg.add_node("Y", NodeData(label="Y concept", score=0.4))
    # link them
    rg.add_edge("X", "Y", relation="supports", weight=0.9)
    assert "X" in rg.graph.nodes
    assert "Y" in rg.graph.nodes
    # ensure edge exists with correct attributes
    assert rg.graph.has_edge("X", "Y")
    attrs = rg.graph.get_edge_data("X", "Y")
    assert attrs["relation"] == "supports"
    # weight should match expected value within a small tolerance
    assert math.isclose(attrs["weight"], 0.9, rel_tol=1e-6)


def test_from_csv_and_metrics() -> None:
    """Test constructing a graph from a CSV and computing metrics."""
    # Use a temporary directory to write the CSV file
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        csv_path = Path(tmpdir) / "relationships.csv"
        df = pd.DataFrame({
            "source_id": ["A", "B", "A"],
            "source_label": ["God", "Logic", "God"],
            "target_id": ["B", "C", "C"],
            "target_label": ["Logic", "Absurdity", "Absurdity"],
            "relation": ["influences", "contradicts", "resolves"],
            "source_score": [0.6, 0.7, 0.6],
            "target_score": [0.7, 0.5, 0.5],
        })
        df.to_csv(csv_path, index=False)

        rg = ReasoningGraph()
        rg.from_csv(csv_path)
        # Should have three nodes and three edges
        assert len(rg.graph.nodes) == 3
        assert len(rg.graph.edges) == 3
        # Compute some metrics (no exception)
        dc = rg.compute_degree_centrality()
        bc = rg.compute_betweenness_centrality()
        pr = rg.compute_pagerank()
        # The sum of degree centralities should equal the number of nodes
        assert math.isclose(sum(dc.values()), len(dc), rel_tol=1e-6)
        assert len(bc) == len(dc) == len(pr)