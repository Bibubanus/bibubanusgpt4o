"""Tests for the Critic and Quarantine modules.

These tests verify that the critic returns expected keys in its audit
report and that the quarantine correctly flags and reintegrates nodes
based on their scores.
"""


from ultimai.graph_manager import ReasoningGraph, NodeData
from ultimai.critic import Critic
from ultimai.quarantine import Quarantine


def build_score_graph() -> ReasoningGraph:
    rg = ReasoningGraph()
    # Node A has high score, B medium, C low
    rg.add_node("A", NodeData(label="A", score=0.8))
    rg.add_node("B", NodeData(label="B", score=0.5))
    rg.add_node("C", NodeData(label="C", score=0.2))
    # connect nodes
    rg.add_edge("A", "B", relation="influences")
    rg.add_edge("B", "C", relation="contradicts")
    return rg


def test_audit_report_keys() -> None:
    rg = build_score_graph()
    critic = Critic()
    report = critic.audit_graph(rg)
    # Required keys
    for key in [
        'num_nodes', 'num_edges', 'isolated_nodes', 'score_variance',
        'hubs', 'dead_ends', 'quality_score', 'recommendations'
    ]:
        assert key in report
    # quality score should be between 0 and 1
    assert 0.0 <= report['quality_score'] <= 1.0


def test_quarantine_and_reintegration() -> None:
    rg = build_score_graph()
    quarantine = Quarantine(threshold=0.5)
    # C has score 0.2 < threshold so should be quarantined
    quarantined = quarantine.evaluate(rg)
    assert 'C' in quarantined
    assert rg.graph.nodes['C'].get('quarantined') is True
    # raise the score and reintegrate
    rg.graph.nodes['C']['score'] = 0.6
    reintegrated = quarantine.reintegrate(rg, min_score=0.5)
    assert 'C' in reintegrated
    assert 'C' not in quarantine.quarantined
    assert rg.graph.nodes['C'].get('quarantined') is False